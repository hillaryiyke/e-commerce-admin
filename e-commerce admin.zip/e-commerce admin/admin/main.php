<div class="main">
   <div>
        <div class="body"><h2>WELCOME TO ERNEST SITE</h2></div>
        <div class="bodytest">
            total tax <br>$5000
            daily servive <br>$4321
            income <br>$7000
            product <br>560
            expensis <br>$540
        </div>

   </div>
</div>