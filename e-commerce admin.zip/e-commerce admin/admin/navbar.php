<div class="navb">
    <img src="" alt="logo" srcset="">
    <div class="main_nav">
    <li><a href="index.php">Home</a></li> 
    <li><a href="addProduct.php">Add Product</a></li>
    <li><a href="http://">All Produc</a></li>
    <li><a href="http://">Left Produc</a></li>
    <li><a href="http://">LACE</a></li>  
    <li><a href="http://">SENATOR</a></li>  
    <li><a href="http://">HOODIE</a></li>
    <li><a href="http://">SHIRT</a></li>
    <li><a href="http://">Profile</a></li>
    </div>
</div>