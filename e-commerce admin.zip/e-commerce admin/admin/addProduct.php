<?php
 include_once 'header.php';
 include_once 'navbar.php';
?>
<body>
<div class="main">
   <div>
        <div class="addp"><h2>ADD PRODUCT TO DATABASE</h2></div>
        <div class="bodytest">
           <div class="form_data">
                <form action="" method="post">
                    <div class="form_body">
                        <div>
                            <input type="text" name="title" id="" placeholder="Enter Title">
                        </div>
                        <div>
                            <input type="text" name="name" id="" placeholder="Enter Product name">
                        </div>
                        <div>
                            <select name="category" id="" class="cat">
                                <option >--Select Category--</option>
                                <option  value="Jeans">Jeans</option>
                                <option  value="Agbada">Agbada</option>
                                <option  value="Shirt">Shirt</option>
                            </select>
                        </div>
                        <div>
                             <input type="number" name="price" id="" placeholder="Enter Product Price:( 0.00)">
                        </div>
                        <div class="produFile">
                             <input type="file" name="image" id="" class="produFile" >
                        </div>
                        <div>
                            <button type="submit" name="add">Add</button>
                        </div>
                    </div>
                </form>
           </div>
        </div>

   </div>
</div>
</body>
</html><?php
 
  include_once 'footer.php';
?>
      