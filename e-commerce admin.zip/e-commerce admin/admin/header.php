<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/pro1.css">
</head>
<body>
    <div class="wrapper">
        <div class="my_header">
            <h1>ERNEST</h1>
            <input type="text"placeholder="search..." class="searchinput">
            <h4>
                <form action="">
                    <button>»LOG OUT</button>
                </form>
            </h4>
        </div>